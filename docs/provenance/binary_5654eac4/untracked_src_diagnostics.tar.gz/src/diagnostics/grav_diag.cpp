//========================================================================================
// AthenaPK - self-gravity (Poisson) solver convergence diagnostics. See grav_diag.hpp.
//========================================================================================

#include <iostream>
#include <string>

#include <parthenon/package.hpp>
#include <solvers/solver_base.hpp>

#include "grav_diag.hpp"

namespace Diagnostics {

using parthenon::Real;
using parthenon::TaskStatus;

namespace {
// Param keys used to hand the recorded scalars from the post-solve task to the history
// reductions. Mutable, and deliberately NOT Restart mutability: they describe the most
// recent solve, so a restart legitimately starts them at "no solve yet" (-1).
constexpr char kIters[] = "grav_last_iters";
constexpr char kRes[] = "grav_last_res";
constexpr char kNonconv[] = "grav_last_nonconv";
constexpr char kNonconvCount[] = "grav_nonconv_count";
} // namespace

Real GravDiagReport(MeshData<Real> *md, GravDiag which) {
  auto pkg = md->GetParentPointer()->packages.Get("self_gravity");
  switch (which) {
  case GravDiag::iters:
    return pkg->Param<Real>(kIters);
  case GravDiag::res:
    return pkg->Param<Real>(kRes);
  case GravDiag::nonconv:
    return pkg->Param<Real>(kNonconv);
  }
  return -1.0;
}

TaskStatus GravDiagRecord(Mesh *pmesh) {
  auto pkg = pmesh->packages.Get("self_gravity");
  auto psolver =
      pkg->Param<std::shared_ptr<parthenon::solvers::SolverBase>>("solver_pointer");

  // GetFinalIterations() returns final_iteration + 1 (see solver_base.hpp), i.e. the
  // number of iterations actually taken.
  const int iters = psolver->GetFinalIterations();
  const Real res = psolver->GetFinalResidual();
  const int max_iters = pkg->Param<int>("grav_max_iters");

  // The solver's completion task fires when EITHER a tolerance is met OR the ceiling is
  // reached, with no way to distinguish them from outside -- so reconstruct the
  // distinction here from the iteration count, which is the only observable that differs.
  const bool bailed = (iters >= max_iters);

  pkg->UpdateParam<Real>(kIters, static_cast<Real>(iters));
  pkg->UpdateParam<Real>(kRes, res);
  pkg->UpdateParam<Real>(kNonconv, bailed ? 1.0 : 0.0);

  if (bailed) {
    const int n = pkg->Param<int>(kNonconvCount) + 1;
    pkg->UpdateParam<int>(kNonconvCount, n);
    // Warn on the first occurrence and then geometrically, so a persistently
    // non-converging run neither hides nor drowns the log.
    if (parthenon::Globals::my_rank == 0 &&
        (n <= 4 || n == 10 || n == 100 || n == 1000 || n % 10000 == 0)) {
      std::cout << "## WARNING [self-gravity] Poisson solve did NOT converge: used all "
                << iters << " of max_iterations=" << max_iters
                << " with rms residual " << res
                << " (tolerance not met). Occurrence #" << n
                << ". The gravitational potential this step is only as good as that "
                   "residual -- see WP-5 in VALIDATION_PLAN.md."
                << std::endl;
    }
  }
  return TaskStatus::complete;
}

} // namespace Diagnostics

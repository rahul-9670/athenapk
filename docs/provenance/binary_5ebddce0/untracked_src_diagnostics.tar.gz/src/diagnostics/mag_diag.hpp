//========================================================================================
// AthenaPK - magnetic-transport (fossil-field) history diagnostics.
//
// FLAGSHIP AUDIT ITEM 2. Peak ME/E and rho_max are safety diagnostics: they cannot say
// WHERE the magnetic flux went. For a fossil-field result the decisive question is whether
// the PHYSICAL transport coefficients dominate a MEASURED numerical transport residual, so
// the run has to report the terms of the induction/energy budget, not just field strength.
//
// Everything here is a volume-summed history reduction over interior cells, gated on
// hydro/mag_diag (default OFF, and writing nothing back into the state => bit-identical
// when off). J = curl B by central differences on the cell-centered primitive B -- the SAME
// stencil the jeans_nonideal current-sheet refinement criterion uses, so the refinement
// trigger and the dissipation diagnostic see one current.
//
// UNITS: Heaviside-Lorentz code units throughout (P_mag = B^2/2, J = curl B with no 4pi/c;
// see CLAUDE.md). Ohmic heating per volume is eta_O |J|^2 and ambipolar heating per volume
// is eta_A |J_perp|^2 with J_perp = J - (J.bhat) bhat, matching the flux kernels.
//
// Columns (all UserHistoryOperation::sum; form ratios in analysis):
//   mag-Jsq      = int |J|^2 dV                total current content
//   mag-Hc       = int B.J dV                  CURRENT helicity -- gauge-invariant, unlike
//                                              magnetic helicity int A.B dV, so it needs no
//                                              vector potential and no gauge choice. It is
//                                              the sign/handedness tracer of the field.
//   mag-MEtor    = int B_phi^2/2 dV            toroidal ME about the z axis (the rotation
//   mag-MEpol    = int (B^2 - B_phi^2)/2 dV    axis and the initial B0z direction)
//   mag-dissO    = int eta_O |J|^2 dV          resolved OHMIC dissipation      (eta cache)
//   mag-dissA    = int eta_A |J_perp|^2 dV     resolved AMBIPOLAR dissipation  (eta cache)
//   mag-dissOcap = int eta_O |J|^2 dV over cells where the eta_O ceiling is ACTIVE
//   mag-dissAcap = int eta_A |J_perp|^2 dV over cells where the eta_A ceiling is ACTIVE
//
// The last two are the direct answer to "what fraction of the magnetic dissipation happens
// in capped cells" -- i.e. how much of the flux loss is a numerical stabilizer rather than
// physics. They require diffusion/cap_diag=true (see CapDiagIdx in diffusion.hpp).
//========================================================================================
#ifndef DIAGNOSTICS_MAG_DIAG_HPP_
#define DIAGNOSTICS_MAG_DIAG_HPP_

#include <parthenon/package.hpp>

using namespace parthenon::package::prelude;

namespace Diagnostics {

//! Which volume-summed magnetic-transport integral to reduce.
enum class MagDiag {
  Jsq,      // int |J|^2 dV
  Hc,       // int B.J dV            (current helicity)
  MEtor,    // int B_phi^2/2 dV      (toroidal, about the z axis)
  MEpol,    // int B_pol^2/2 dV
  dissO,    // int eta_O |J|^2 dV
  dissA,    // int eta_A |J_perp|^2 dV
  dissOcap, // dissO restricted to cells where the eta_O ceiling is active
  dissAcap  // dissA restricted to cells where the eta_A ceiling is active
};

//! Volume-summed magnetic-transport reduction over interior cells. `need_eta` variants
//! read the cached "nonideal_eta" field; the `*cap` variants additionally read
//! "diff.capdiag". The caller (hydro.cpp) only registers the variants whose inputs exist.
Real MagDiagReduce(MeshData<Real> *md, MagDiag which);

} // namespace Diagnostics

#endif // DIAGNOSTICS_MAG_DIAG_HPP_

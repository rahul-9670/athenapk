//========================================================================================
// AthenaPK - magnetic-transport (fossil-field) history diagnostics. See mag_diag.hpp.
//========================================================================================

#include <cmath>
#include <string>
#include <vector>

#include <parthenon/package.hpp>

#include "../hydro/diffusion/diffusion.hpp"
#include "../main.hpp"
#include "mag_diag.hpp"

namespace Diagnostics {

Real MagDiagReduce(MeshData<Real> *md, MagDiag which) {
  const auto &prim = md->PackVariables(std::vector<std::string>{"prim"});

  const bool need_eta = (which == MagDiag::dissO || which == MagDiag::dissA ||
                         which == MagDiag::dissOcap || which == MagDiag::dissAcap);
  const bool need_cap = (which == MagDiag::dissOcap || which == MagDiag::dissAcap);
  // Dummy-alias to `prim` when unused: PackVariables on a field that is not registered
  // would throw, and the lambda must still capture *something*.
  const auto &eta =
      need_eta ? md->PackVariables(std::vector<std::string>{"nonideal_eta"}) : prim;
  const auto &capd =
      need_cap ? md->PackVariables(std::vector<std::string>{"diff.capdiag"}) : prim;

  IndexRange ib = md->GetBlockData(0)->GetBoundsI(IndexDomain::interior);
  IndexRange jb = md->GetBlockData(0)->GetBoundsJ(IndexDomain::interior);
  IndexRange kb = md->GetBlockData(0)->GetBoundsK(IndexDomain::interior);

  Real sum = 0.0;
  Kokkos::parallel_reduce(
      "MagDiagReduce",
      Kokkos::MDRangePolicy<Kokkos::Rank<4>>(
          DevExecSpace(), {0, kb.s, jb.s, ib.s},
          {prim.GetDim(5), kb.e + 1, jb.e + 1, ib.e + 1}, {1, 1, 1, ib.e + 1 - ib.s}),
      KOKKOS_LAMBDA(const int b, const int k, const int j, const int i, Real &lsum) {
        const auto &w = prim(b);
        const auto &coords = prim.GetCoords(b);
        const Real dV = coords.CellVolume(k, j, i);
        const Real bx = w(IB1, k, j, i), by = w(IB2, k, j, i), bz = w(IB3, k, j, i);

        if (which == MagDiag::MEtor || which == MagDiag::MEpol) {
          // Toroidal direction about the z axis: phihat = (-y, x, 0)/R. The z axis is both
          // the rotation axis (omegatff) and the initial field direction (B0z), so this is
          // the physically meaningful split for the FHC problem. On the axis (R -> 0) the
          // toroidal component is undefined; there B is essentially poloidal, so assign
          // the whole cell to poloidal.
          const Real x = coords.Xc<1>(i), y = coords.Xc<2>(j);
          const Real R2 = x * x + y * y;
          Real b_tor2 = 0.0;
          if (R2 > 0.0) {
            const Real b_tor = (-y * bx + x * by) / std::sqrt(R2);
            b_tor2 = b_tor * b_tor;
          }
          const Real b2 = bx * bx + by * by + bz * bz;
          lsum += 0.5 * ((which == MagDiag::MEtor) ? b_tor2 : (b2 - b_tor2)) * dV;
          return;
        }

        // J = curl B, central differences on cell-centered primitive B. Same stencil as the
        // jeans_nonideal current-sheet criterion (prim is FillGhost, so ghosts are valid).
        const Real dx = coords.Dxc<1>(k, j, i);
        const Real dy = coords.Dxc<2>(k, j, i);
        const Real dz = coords.Dxc<3>(k, j, i);
        const Real Jx = (w(IB3, k, j + 1, i) - w(IB3, k, j - 1, i)) / (2.0 * dy) -
                        (w(IB2, k + 1, j, i) - w(IB2, k - 1, j, i)) / (2.0 * dz);
        const Real Jy = (w(IB1, k + 1, j, i) - w(IB1, k - 1, j, i)) / (2.0 * dz) -
                        (w(IB3, k, j, i + 1) - w(IB3, k, j, i - 1)) / (2.0 * dx);
        const Real Jz = (w(IB2, k, j, i + 1) - w(IB2, k, j, i - 1)) / (2.0 * dx) -
                        (w(IB1, k, j + 1, i) - w(IB1, k, j - 1, i)) / (2.0 * dy);
        const Real Jsq = Jx * Jx + Jy * Jy + Jz * Jz;

        if (which == MagDiag::Jsq) {
          lsum += Jsq * dV;
        } else if (which == MagDiag::Hc) {
          lsum += (bx * Jx + by * Jy + bz * Jz) * dV;
        } else if (which == MagDiag::dissO || which == MagDiag::dissOcap) {
          if (which == MagDiag::dissOcap &&
              capd(b, CapDiagIdx::flagO, k, j, i) == 0.0) {
            return;
          }
          lsum += eta(b, NonidealEtaIdx::O, k, j, i) * Jsq * dV;
        } else if (which == MagDiag::dissA || which == MagDiag::dissAcap) {
          if (which == MagDiag::dissAcap &&
              capd(b, CapDiagIdx::flagA, k, j, i) == 0.0) {
            return;
          }
          // Ambipolar heats on the PERPENDICULAR current only: J_perp = J - (J.bhat)bhat.
          const Real b2 = bx * bx + by * by + bz * bz;
          Real Jperp2 = Jsq;
          if (b2 > 0.0) {
            const Real Jpar = (Jx * bx + Jy * by + Jz * bz) / std::sqrt(b2);
            Jperp2 = Jsq - Jpar * Jpar;
            if (Jperp2 < 0.0) Jperp2 = 0.0; // round-off guard
          }
          lsum += eta(b, NonidealEtaIdx::A, k, j, i) * Jperp2 * dV;
        }
      },
      sum);
  return sum;
}

} // namespace Diagnostics
